.. _bool3:

Bool3
=====

.. automodule:: lctools.bool3
   :members:
   :special-members:
   :undoc-members:
   :show-inheritance:
