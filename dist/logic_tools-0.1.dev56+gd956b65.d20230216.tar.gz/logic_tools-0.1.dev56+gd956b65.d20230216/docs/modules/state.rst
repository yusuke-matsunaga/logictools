.. _state:

Bool3
=====

.. automodule:: lctools.state
   :members:
   :special-members:
   :undoc-members:
   :show-inheritance:
